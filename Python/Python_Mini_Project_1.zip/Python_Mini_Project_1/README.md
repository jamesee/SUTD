# Mini Projects
Mini Project templates for Fundamentals in Python SG Innovate.

## Mini Project 1
This mini project is to create a simple html pages to generate random number and sort them.

[Handout](mp_sort/README.md)

## Mini Project 2
This mini project is to create a simple web application for math quiz where users can create simple math challenges and take up challenge from others.

[Handout](mp_calc/README.md)

## Mini Project 3

This mini project is to create a simple AI Tic Tac Toe game where a user can play Tic Tac Toe against a computer. 

[Handout](mp_tictactoe/README.md)

## Groupings

Students should work as a pair and practice pair programming in doing the mini project. 

